package guiarch;

public class GUIarch {

    public static void main(String[] args) {
        LabelFrame m = new LabelFrame();
        m.setVisible(true);
        
    }
    
}
