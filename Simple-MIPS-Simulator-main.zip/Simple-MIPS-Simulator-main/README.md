# Simple MIPS Simulator
This App simulate the mips processor while running by showing the input and output of each component of the mips processor after each line of code is executed
